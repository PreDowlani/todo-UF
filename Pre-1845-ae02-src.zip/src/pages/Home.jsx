import React from "react";
import ReactPlayer from "react-player";

const Home = () => {
  return (
    <div className="app-home">
      <div className="home">
        <div id="homeh1">
          <h1>Academia de Estafadores </h1>
        </div>{" "}
        <br />
      </div>
    </div>
  );
};

export default Home;
